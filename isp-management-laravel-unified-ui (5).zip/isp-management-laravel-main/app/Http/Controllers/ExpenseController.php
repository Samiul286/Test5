<?php

namespace App\Http\Controllers;

use App\Models\Expense;
use App\Models\ExpenseCategory;
use App\Models\Payment;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\Facade\Pdf;

class ExpenseController extends Controller
{
    public function index(Request $request)
    {
        $expenses = Expense::with(['category', 'createdBy'])
            ->when($request->search, fn($q) =>
                $q->where('description', 'like', "%{$request->search}%")
                  ->orWhere('payee', 'like', "%{$request->search}%")
                  ->orWhere('expense_no', 'like', "%{$request->search}%"))
            ->when($request->category_id, fn($q) =>
                $q->where('category_id', $request->category_id))
            ->when($request->status, fn($q) =>
                $q->where('status', $request->status))
            ->when($request->payment_method, fn($q) =>
                $q->where('payment_method', $request->payment_method))
            ->when($request->date_from, fn($q) =>
                $q->whereDate('expense_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) =>
                $q->whereDate('expense_date', '<=', $request->date_to))
            ->when($request->month, fn($q) =>
                $q->byMonth($request->month))
            ->latest('expense_date')
            ->orderBy('id', 'DESC')
            ->paginate($request->get('per_page', 20))
            ->withQueryString();

        $categories = ExpenseCategory::active()->ordered()->get();

        $thisMonth   = now()->format('Y-m');
        $totalThis   = Expense::active()->byMonth($thisMonth)->sum('amount');
        $totalLast   = Expense::active()->byMonth(now()->subMonth()->format('Y-m'))->sum('amount');
        $pendingCount = Expense::pending()->count();
        $todayTotal  = Expense::active()->today()->sum('amount');

        return view('expenses.index', compact(
            'expenses', 'categories',
            'totalThis', 'totalLast', 'pendingCount', 'todayTotal'
        ));
    }

    public function create()
    {
        $categories = ExpenseCategory::active()->ordered()->get();
        return view('expenses.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id'    => 'required|exists:expense_categories,id',
            'amount'         => 'required|numeric|min:0.01|max:99999999',
            'expense_date'   => 'required|date|before_or_equal:today',
            'payment_method' => 'required|in:cash,bkash,nagad,rocket,bank,cheque,card',
            'transaction_id' => 'nullable|string|max:100',
            'payee'          => 'nullable|string|max:150',
            'reference_no'   => 'nullable|string|max:100',
            'description'    => 'nullable|string|max:500',
            'receipt'        => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        $receiptPath = null;
        if ($request->hasFile('receipt')) {
            $receiptPath = $request->file('receipt')
                ->store('receipts/' . date('Y/m'), 'public');
        }

        $expense = Expense::create([
            'category_id'    => $validated['category_id'],
            'amount'         => $validated['amount'],
            'expense_date'   => $validated['expense_date'],
            'payment_method' => $validated['payment_method'],
            'transaction_id' => $validated['transaction_id'] ?? null,
            'payee'          => $validated['payee'] ?? null,
            'reference_no'   => $validated['reference_no'] ?? null,
            'description'    => $validated['description'] ?? null,
            'receipt_path'   => $receiptPath,
            'status'         => 'approved',        // auto-approve; add approval flow later
            'created_by'     => auth()->id(),
            'approved_by'    => auth()->id(),
            'approved_at'    => now(),
        ]);

        ActivityLog::log('Expense created', 'Expense', $expense->id, null, $expense->toArray());

        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Expense saved successfully.',
                'expense' => $expense->load('category'),
            ]);
        }

        return redirect()->route('expenses.index')
            ->with('success', "Expense {$expense->expense_no} saved successfully.");
    }

    public function show(Expense $expense)
    {
        $expense->load(['category', 'createdBy', 'approvedBy']);
        return view('expenses.show', compact('expense'));
    }

    public function edit(Expense $expense)
    {
        if ($expense->isVoid()) {
            return back()->with('error', 'Void expenses cannot be edited.');
        }

        $categories = ExpenseCategory::active()->ordered()->get();
        return view('expenses.edit', compact('expense', 'categories'));
    }

    public function update(Request $request, Expense $expense)
    {
        if ($expense->isVoid()) {
            return back()->with('error', 'Void expenses cannot be edited.');
        }

        $validated = $request->validate([
            'category_id'    => 'required|exists:expense_categories,id',
            'amount'         => 'required|numeric|min:0.01|max:99999999',
            'expense_date'   => 'required|date|before_or_equal:today',
            'payment_method' => 'required|in:cash,bkash,nagad,rocket,bank,cheque,card',
            'transaction_id' => 'nullable|string|max:100',
            'payee'          => 'nullable|string|max:150',
            'reference_no'   => 'nullable|string|max:100',
            'description'    => 'nullable|string|max:500',
            'receipt'        => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        $old = $expense->toArray();

        // Replace receipt if new file uploaded
        if ($request->hasFile('receipt')) {
            if ($expense->receipt_path) {
                Storage::disk('public')->delete($expense->receipt_path);
            }
            $validated['receipt_path'] = $request->file('receipt')
                ->store('receipts/' . date('Y/m'), 'public');
        }

        $expense->update([
            'category_id'    => $validated['category_id'],
            'amount'         => $validated['amount'],
            'expense_date'   => $validated['expense_date'],
            'payment_method' => $validated['payment_method'],
            'transaction_id' => $validated['transaction_id'] ?? null,
            'payee'          => $validated['payee'] ?? null,
            'reference_no'   => $validated['reference_no'] ?? null,
            'description'    => $validated['description'] ?? null,
            'receipt_path'   => $validated['receipt_path'] ?? $expense->receipt_path,
        ]);

        ActivityLog::log('Expense updated', 'Expense', $expense->id, $old, $expense->toArray());

        return redirect()->route('expenses.show', $expense)
            ->with('success', 'Expense updated successfully.');
    }

    public function void(Request $request, Expense $expense)
    {
        if ($expense->isVoid()) {
            return back()->with('error', 'This expense has already been voided.');
        }

        $request->validate([
            'reason' => 'required|string|max:255',
        ]);

        $expense->update([
            'status'        => 'void',
            'reject_reason' => $request->reason,
        ]);

        ActivityLog::log('Expense voided', 'Expense', $expense->id);

        return back()->with('success', 'Expense voided. It will no longer appear in reports.');
    }

    public function destroy(Expense $expense)
    {
        // Only allow deleting already-voided records
        if (! $expense->isVoid()) {
            return back()->with('error', 'Please void the expense first before deleting.');
        }

        if ($expense->receipt_path) {
            Storage::disk('public')->delete($expense->receipt_path);
        }

        ActivityLog::log('Expense deleted', 'Expense', $expense->id, $expense->toArray(), null);

        $expense->forceDelete();

        return redirect()->route('expenses.index')
            ->with('success', 'Expense permanently deleted.');
    }

     public function profitLoss(Request $request)
    {
        $from = $request->get('from_date', now()->startOfMonth()->format('Y-m-d'));
        $to   = $request->get('to_date',   now()->format('Y-m-d'));
        if ($from > $to) [$from, $to] = [$to, $from];

        $cursor  = \Carbon\Carbon::parse($from)->startOfMonth();
        $endDate = \Carbon\Carbon::parse($to);
        $rows = []; $grandIncome = 0; $grandExpense = 0;

        while ($cursor->lte($endDate)) {
            $mFrom = $cursor->copy()->startOfMonth()->lt(\Carbon\Carbon::parse($from))
                ? $from : $cursor->copy()->startOfMonth()->format('Y-m-d');
            $mTo = $cursor->copy()->endOfMonth()->gt($endDate)
                ? $to : $cursor->copy()->endOfMonth()->format('Y-m-d');

            // শুধু Income table — সব source already include (monthly bill, manual, sale etc)
            $totalIncome = (float) \App\Models\Income::active()
                ->whereBetween('income_date', [$mFrom, $mTo])
                ->sum('amount'); 

            $totalExpense = (float) Expense::active()
                ->whereBetween('expense_date', [$mFrom, $mTo])
                ->sum('amount');

            $netProfit = $totalIncome - $totalExpense;
            $margin    = $totalIncome > 0 ? round(($netProfit / $totalIncome) * 100, 1) : 0;

                $rows[] = [
                    'month'         => $cursor->format('Y-m'),
                    'month_label'   => $cursor->format('M Y'),
                    'total_income'  => $totalIncome,
                    'total_expense' => $totalExpense,
                    'net_profit'    => $netProfit,
                    'margin'        => $margin,
                ];

            $grandIncome += $totalIncome;
            $grandExpense += $totalExpense;
            $cursor->addMonth();
        }

        $grandProfit = $grandIncome - $grandExpense;
        $grandMargin = $grandIncome > 0 ? round(($grandProfit / $grandIncome) * 100, 1) : 0;

        $chartData = collect($rows)->map(fn($r) => [
            'month'   => $r['month_label'],
            'income'  => $r['total_income'],
            'expense' => $r['total_expense'],
            'profit'  => $r['net_profit'],
        ])->values();
        $incomeByCategory = \App\Models\Income::active()
            ->whereBetween('income_date', [$from, $to])
            ->join('income_categories', 'incomes.category_id', '=', 'income_categories.id')
            ->selectRaw('income_categories.name as category_name, SUM(incomes.amount) as total')
            ->groupBy('income_categories.name')
            ->orderByDesc('total')
            ->get();

        $expenseByCategory = Expense::active()
            ->whereBetween('expense_date', [$from, $to])
            ->join('expense_categories', 'expenses.category_id', '=', 'expense_categories.id')
            ->selectRaw('expense_categories.name as category_name, SUM(expenses.amount) as total')
            ->groupBy('expense_categories.name')
            ->orderByDesc('total')
            ->get();
        return view('accounting.profit-loss', compact(
            'from', 'to', 'rows','expenseByCategory','incomeByCategory',
            'grandIncome', 'grandExpense', 'grandProfit', 'grandMargin', 'chartData'
        ));
    }
   public function editData(Expense $expense)
    {
        return response()->json([
            'success' => true,
            'expense' => [
                'id'             => $expense->id,
                'category_id'    => $expense->category_id,
                'amount'         => $expense->amount,
                'expense_date'   => $expense->expense_date->format('Y-m-d'),
                'payment_method' => $expense->payment_method,
                'transaction_id' => $expense->transaction_id ?? '',
                'payee'          => $expense->payee ?? '',
                'reference_no'   => $expense->reference_no ?? '',
                'description'    => $expense->description ?? '',
            ]
        ]);
    }
    public function profitLossPdf(Request $request)
    {
        $from = $request->get('from_date', now()->startOfMonth()->format('Y-m-d'));
        $to   = $request->get('to_date',   now()->format('Y-m-d'));

        if ($from > $to) [$from, $to] = [$to, $from];

        $rows = []; $grandIncome = 0; $grandExpense = 0;
        $cursor  = \Carbon\Carbon::parse($from)->startOfMonth();
        $endDate = \Carbon\Carbon::parse($to);

        while ($cursor->lte($endDate)) {
            $mFrom = $cursor->copy()->startOfMonth()->lt(\Carbon\Carbon::parse($from))
                ? $from : $cursor->copy()->startOfMonth()->format('Y-m-d');
            $mTo = $cursor->copy()->endOfMonth()->gt($endDate)
                ? $to : $cursor->copy()->endOfMonth()->format('Y-m-d');

            $monthlyBill  = (float) Payment::active()->whereBetween('payment_date', [$mFrom, $mTo])->sum('amount');
            $manualIncome = class_exists(\App\Models\Income::class) ? (float) \App\Models\Income::active()->whereBetween('income_date', [$mFrom, $mTo])->sum('amount') : 0;
            $totalIncome  = $monthlyBill + $manualIncome;
            $totalExpense = (float) Expense::active()->whereBetween('expense_date', [$mFrom, $mTo])->sum('amount');
            $netProfit    = $totalIncome - $totalExpense;
            $margin       = $totalIncome > 0 ? round(($netProfit / $totalIncome) * 100, 1) : 0;

            $rows[] = [
                'month' => $cursor->format('Y-m'), 'month_label' => $cursor->format('M Y'),
                'monthly_bill' => $monthlyBill, 'manual_income' => $manualIncome,
                'total_income' => $totalIncome, 'total_expense' => $totalExpense,
                'net_profit' => $netProfit, 'margin' => $margin,
            ];
            $grandIncome += $totalIncome; $grandExpense += $totalExpense;
            $cursor->addMonth();
        }

        $grandProfit = $grandIncome - $grandExpense;
        $grandMargin = $grandIncome > 0 ? round(($grandProfit / $grandIncome) * 100, 1) : 0;

        $pdf = Pdf::loadView('accounting.profit-loss-pdf', compact(
            'from', 'to', 'rows', 'grandIncome', 'grandExpense', 'grandProfit', 'grandMargin'
        ))->setPaper('a4', 'landscape');

        return $pdf->download('profit-loss-' . $from . '-to-' . $to . '.pdf');
    }

    public function chartData(Request $request)
    {
        $months = collect(range(5, 0))->map(function ($i) {
            $m    = now()->subMonths($i)->format('Y-m');
            [$y, $mo] = explode('-', $m);

            return [
                'label'   => now()->subMonths($i)->format('M'),
                'expense' => (float) Expense::active()
                    ->whereYear('expense_date', $y)
                    ->whereMonth('expense_date', $mo)
                    ->sum('amount'),
            ];
        });

        return response()->json($months);
    }

    public function categoriesIndex()
    {
        $categories = ExpenseCategory::withCount('expenses')->ordered()->get();
        return view('expenses.categories', compact('categories'));
    }

    public function categoryStore(Request $request)
    {
        $request->validate([
            'name'  => 'required|string|max:100|unique:expense_categories,name',
            'color' => 'nullable|string|max:7',
            'icon'  => 'nullable|string|max:50',
        ]);

        $category = ExpenseCategory::create($request->only('name', 'color', 'icon', 'description'));

        return back()->with('success', "Category '{$category->name}' created.");
    }

    public function categoryUpdate(Request $request, ExpenseCategory $expenseCategory)
    {
        if($expenseCategory->is_system==1){
            return back()->with('error', 'This category cannot be updated because it is a built-in system category');
        }        
        $request->validate([
            'name'  => 'required|string|max:100|unique:expense_categories,name,' . $expenseCategory->id,
            'color' => 'nullable|string|max:7',
            'icon'  => 'nullable|string|max:50',
        ]);

        $expenseCategory->update($request->only('name', 'color', 'icon', 'description', 'is_active'));

        return back()->with('success', 'Category updated.');
    }

    public function categoryDestroy(ExpenseCategory $expenseCategory)
    {
        if ($expenseCategory->expenses()->count() > 0) {
            return back()->with('error', 'Cannot delete — expenses are linked to this category.');
        }
        
        if($expenseCategory->is_system==1){
            return back()->with('error', 'This category cannot be deleted because it is a built-in system category');
        }         

        $expenseCategory->delete();

        return back()->with('success', 'Category deleted.');
    }

    public function exportXlsx(Request $request)
    {
        $expenses = $this->getFilteredExpenses($request);

        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Expenses');

        $headers = ['A'=>'#','B'=>'Expense No','C'=>'Date','D'=>'Category',
                    'E'=>'Description','F'=>'Payee','G'=>'Method',
                    'H'=>'Amount','I'=>'Status'];

        foreach ($headers as $col => $label) {
            $sheet->setCellValue($col.'1', $label);
            $sheet->getStyle($col.'1')->getFont()->setBold(true);
            $sheet->getStyle($col.'1')->getFill()
                ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                ->getStartColor()->setRGB('c0392b');
            $sheet->getStyle($col.'1')->getFont()->getColor()->setRGB('FFFFFF');
        }

        foreach ($expenses as $i => $exp) {
            $row = $i + 2;
            $sheet->setCellValue('A'.$row, $i + 1);
            $sheet->setCellValue('B'.$row, $exp->expense_no);
            $sheet->setCellValue('C'.$row, optional($exp->expense_date)->format('d-m-Y'));
            $sheet->setCellValue('D'.$row, $exp->category->name ?? '—');
            $sheet->setCellValue('E'.$row, $exp->description ?? '—');
            $sheet->setCellValue('F'.$row, $exp->payee ?? '—');
            $sheet->setCellValue('G'.$row, strtoupper($exp->payment_method));
            $sheet->setCellValue('H'.$row, (float) $exp->amount);
            $sheet->setCellValue('I'.$row, ucfirst($exp->status));
        }

        foreach (range('A', 'I') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        $filename = 'expenses-' . now()->format('Y-m-d') . '.xlsx';
        $tmpPath  = storage_path('app/' . $filename);
        (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save($tmpPath);

        return response()->download($tmpPath, $filename, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ])->deleteFileAfterSend(true);
    }

    public function exportPdf(Request $request)
    {
        $expenses = $this->getFilteredExpenses($request);

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView(
            'expenses.export-pdf',
            compact('expenses')
        )->setPaper('a4', 'landscape');

        return $pdf->download('expenses-' . now()->format('Y-m-d') . '.pdf');
    }

    private function getFilteredExpenses(Request $request)
    {
        return Expense::with(['category', 'createdBy'])
            ->when($request->search, fn($q) =>
                $q->where('description', 'like', "%{$request->search}%")
                  ->orWhere('payee', 'like', "%{$request->search}%")
                  ->orWhere('expense_no', 'like', "%{$request->search}%"))
            ->when($request->category_id, fn($q) => $q->where('category_id', $request->category_id))
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->payment_method, fn($q) => $q->where('payment_method', $request->payment_method))
            ->when($request->date_from, fn($q) => $q->whereDate('expense_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('expense_date', '<=', $request->date_to))
            ->orderByDesc('expense_date')
            ->orderByDesc('id')
            ->get();
    }

    public function quickAddCategory(Request $request)
    {
        $request->validate([
            'name'  => 'required|string|max:100|unique:expense_categories,name',
            'color' => 'nullable|string|max:7',
            'icon'  => 'nullable|string|max:50',
        ], [
            'name.unique' => 'This category already exists.',
        ]);

        $category = ExpenseCategory::create([
            'name'        => trim($request->name),
            'color'       => $request->color ?? '#6c757d',
            'icon'        => $request->icon ?? null,
            'description' => $request->description ?? null,
            'is_active'   => true,
        ]);

        return response()->json([
            'success'  => true,
            'message'  => "Category '{$category->name}' added successfully.",
            'category' => [
                'id'   => $category->id,
                'name' => $category->name,
            ],
        ]);
    }
}