{{-- resources/views/client/layout.blade.php --}}
{{-- Client Self-Service Portal — the MASTER design reference.
     Visual design tokens & components now live in public/css/unified-theme.css
     and are shared by every portal (Admin, Super Admin, Reseller). --}}
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard') — {{ \App\Models\Setting::get('company_name', 'SmartISP') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    {{-- Unified design system (this portal is the reference) --}}
    <link rel="stylesheet" href="{{ asset('css/unified-theme.css') }}">

    @yield('extra_css')
</head>
<body class="isp-shell">

{{-- Topbar --}}
<div class="isp-topbar">
    <div style="display:flex; align-items:center; gap:12px; min-width:0;">
        <button class="isp-hamburger" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
        <a href="{{ route('client.dashboard') }}" class="isp-topbar-brand">
            <div class="isp-logo-box">{{ strtoupper(substr(\App\Models\Setting::get('company_name', 'S'), 0, 1)) }}</div>
            <span class="isp-brand-name">{{ \App\Models\Setting::get('company_name', 'SmartISP') }}</span>
        </a>
    </div>
    <div class="isp-topbar-right">
        <div class="isp-user-pill" id="ispUserPill">
            <div class="isp-user-avatar">{{ strtoupper(substr(Auth::guard('customer')->user()->name, 0, 2)) }}</div>
            <span class="isp-user-name">{{ Auth::guard('customer')->user()->name }}</span>
            <i class="fas fa-chevron-down isp-chevron"></i>

            <div class="isp-user-dropdown" id="ispUserDropdown">
                <div class="isp-dropdown-header">
                    <div class="isp-dropdown-avatar">{{ strtoupper(substr(Auth::guard('customer')->user()->name, 0, 2)) }}</div>
                    <div style="min-width:0;">
                        <div class="isp-dropdown-name text-truncate">{{ Auth::guard('customer')->user()->name }}</div>
                        <div class="isp-dropdown-sub">Welcome !</div>
                    </div>
                </div>
                <div class="isp-dropdown-divider"></div>
                <a href="{{ route('client.profile') }}" class="isp-dropdown-item">
                    <i class="fas fa-user"></i> My Profile
                </a>
                <div class="isp-dropdown-divider"></div>
                <form method="POST" action="{{ route('client.logout') }}">
                    @csrf
                    <button type="submit" class="isp-dropdown-item isp-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- Sidebar --}}
<div class="isp-sidebar" id="ispSidebar">
    <nav class="isp-sidebar-nav">
        <a href="{{ route('client.dashboard') }}" class="isp-nav-item {{ request()->routeIs('client.dashboard') ? 'active' : '' }}">
            <i class="fas fa-home"></i> Dashboard
        </a>
        <a href="{{ route('client.invoices') }}" class="isp-nav-item {{ request()->routeIs('client.invoices*') ? 'active' : '' }}">
            <i class="fas fa-file-invoice-dollar"></i> Invoice List
        </a>
        <a href="{{ route('client.live-traffic') }}" class="isp-nav-item {{ request()->routeIs('client.live-traffic') ? 'active' : '' }}">
            <i class="fas fa-chart-line"></i> Live Traffic
        </a>
        <a href="{{ route('client.packages') }}" class="isp-nav-item {{ request()->routeIs('client.packages') ? 'active' : '' }}">
            <i class="fas fa-box"></i> Package List
        </a>
        <a href="{{ route('client.tickets') }}" class="isp-nav-item {{ request()->routeIs('client.tickets*') ? 'active' : '' }}">
            <i class="fas fa-ticket-alt"></i> Ticket List
        </a>
        <div class="isp-nav-divider"></div>
        <a href="{{ route('client.profile') }}" class="isp-nav-item {{ request()->routeIs('client.profile*') ? 'active' : '' }}">
            <i class="fas fa-user-cog"></i> Profile
        </a>
        <form method="POST" action="{{ route('client.logout') }}">
            @csrf
            <button type="submit" class="isp-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </form>
    </nav>
</div>

{{-- Main Content --}}
<div class="isp-wrapper">
    <div class="isp-page-content">

        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ session('error') }}</span>
            </div>
        @endif
        @if(session('warning'))
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <span>{{ session('warning') }}</span>
            </div>
        @endif

        @yield('content')
    </div>
</div>

{{-- Footer --}}
<div class="isp-footer">
    {{ date('Y') }} &copy; {{ \App\Models\Setting::get('company_name', 'SmartISP') }}
</div>

<script src="{{ asset('js/unified-theme.js') }}"></script>
@yield('extra_js')
</body>
</html>
