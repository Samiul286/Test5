{{-- resources/views/auth/login.blade.php --}}
@extends('auth.layout')

@section('title', 'Login')
@section('brand_icon', 'fas fa-wifi')
@section('brand_name', 'ISP Management')
@section('brand_tagline', 'Admin & Staff Portal')

@section('auth_content')
<form method="POST" action="{{ route('login') }}">
    @csrf

    <div class="form-group">
        <label>{{ __('Email') }}</label>
        <div class="input-wrap">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                   value="{{ old('email') }}" placeholder="name@company.com"
                   autocomplete="email" autofocus required>
        </div>
        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
        <label>{{ __('Password') }}</label>
        <div class="input-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                   placeholder="••••••••" autocomplete="current-password" required>
        </div>
        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="remember-row">
        <input type="checkbox" name="remember" id="remember" value="1">
        <label for="remember" style="all:unset; cursor:pointer;">{{ __('Remember Me') }}</label>
    </div>

    <button type="submit" class="btn-login">
        <i class="fas fa-sign-in-alt"></i> {{ __('Login') }}
    </button>
</form>
@endsection

@section('auth_links')
    <a href="{{ route('password.request') }}">{{ __('Forgot Your Password?') }}</a>
    <span class="divider">•</span>
    <a href="{{ route('register') }}">{{ __('Register') }}</a>
@endsection
