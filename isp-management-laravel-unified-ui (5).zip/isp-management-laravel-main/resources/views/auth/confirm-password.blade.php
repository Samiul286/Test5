{{-- resources/views/auth/confirm-password.blade.php --}}
{{-- FIX: previously used <x-guest-layout> (nonexistent Breeze component). --}}
@extends('auth.layout')

@section('title', 'Confirm Password')
@section('brand_icon', 'fas fa-shield-alt')
@section('brand_name', 'ISP Management')
@section('brand_tagline', 'This is a secure area')

@section('auth_content')
<p style="font-size:12.5px; color:#888; margin-bottom:1.25rem;">
    {{ __('This is a secure area of the application. Please confirm your password before continuing.') }}
</p>

<form method="POST" action="{{ route('password.confirm') }}">
    @csrf

    <div class="form-group">
        <label>{{ __('Password') }}</label>
        <div class="input-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                   placeholder="••••••••" autocomplete="current-password" autofocus required>
        </div>
        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <button type="submit" class="btn-login">
        <i class="fas fa-check-circle"></i> {{ __('Confirm') }}
    </button>
</form>
@endsection

@section('auth_links')
    <form method="POST" action="{{ route('logout') }}" style="display:inline;">
        @csrf
        <button type="submit" style="background:none;border:none;color:#00c897;font:inherit;cursor:pointer;font-weight:600;">{{ __('Log Out') }}</button>
    </form>
@endsection
