{{-- resources/views/auth/forgot-password.blade.php --}}
{{-- FIX: previously used <x-guest-layout>, a Breeze component that does not exist
     in this project (would throw ViewNotFoundException). Now a unified page. --}}
@extends('auth.layout')

@section('title', 'Forgot Password')
@section('brand_icon', 'fas fa-key')
@section('brand_name', 'ISP Management')
@section('brand_tagline', 'Reset your password')

@section('auth_content')
<p style="font-size:12.5px; color:#888; margin-bottom:1.1rem;">
    {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link.') }}
</p>

<form method="POST" action="{{ route('password.email') }}">
    @csrf

    <div class="form-group">
        <label>{{ __('Email') }}</label>
        <div class="input-wrap">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                   value="{{ old('email') }}" placeholder="name@company.com"
                   autocomplete="email" autofocus required>
        </div>
        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <button type="submit" class="btn-login">
        <i class="fas fa-paper-plane"></i> {{ __('Email Password Reset Link') }}
    </button>
</form>
@endsection

@section('auth_links')
    <a href="{{ route('login') }}">{{ __('Back to login') }}</a>
@endsection
