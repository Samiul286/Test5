{{-- resources/views/auth/verify.blade.php --}}
{{-- Legacy alias — the EmailVerificationPromptController renders auth.verify-email;
     kept for safety and now unified with the shared auth shell. --}}
@extends('auth.verify-email')
