{{-- resources/views/auth/reset-password.blade.php --}}
@extends('auth.layout')

@section('title', 'Reset Password')
@section('brand_icon', 'fas fa-shield-alt')
@section('brand_name', 'ISP Management')
@section('brand_tagline', 'Choose a new password')

@section('auth_content')
<form method="POST" action="{{ route('password.store') }}">
    @csrf
    <input type="hidden" name="token" value="{{ $request->route('token') }}">

    <div class="form-group">
        <label>{{ __('Email') }}</label>
        <div class="input-wrap">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                   value="{{ old('email', $request->email) }}" placeholder="name@company.com"
                   autocomplete="email" autofocus required>
        </div>
        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
        <label>{{ __('Password') }}</label>
        <div class="input-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                   placeholder="••••••••" autocomplete="new-password" required>
        </div>
        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
        <label>{{ __('Confirm Password') }}</label>
        <div class="input-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="password_confirmation" class="form-control"
                   placeholder="••••••••" autocomplete="new-password" required>
        </div>
    </div>

    <button type="submit" class="btn-login">
        <i class="fas fa-check-circle"></i> {{ __('Reset Password') }}
    </button>
</form>
@endsection

@section('auth_links')
    <a href="{{ route('login') }}">{{ __('Back to login') }}</a>
@endsection
