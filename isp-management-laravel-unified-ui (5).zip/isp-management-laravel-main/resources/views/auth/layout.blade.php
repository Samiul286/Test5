{{-- resources/views/auth/layout.blade.php --}}
{{-- Shared auth shell — unified design system (Client Self-Service Portal look).
     Used by: login, register, forgot/reset password, verify-email, confirm-password. --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Login') — {{ config('adminlte.title', 'ISP Management') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/unified-theme.css') }}">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #1a1f36 0%, #2d3561 100%);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
            padding: 16px;
        }
        .login-wrapper { width: 100%; max-width: 400px; }
        .login-card {
            background: #fff; border-radius: 16px;
            padding: 2.5rem 2rem; box-shadow: 0 20px 60px rgba(0,0,0,.3);
        }
        .brand { text-align: center; margin-bottom: 2rem; }
        .brand-logo {
            width: 60px; height: 60px; background: #00c897;
            border-radius: 14px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 12px; font-size: 26px; font-weight: 800; color: #fff;
        }
        .brand-logo i { font-size: 24px; }
        .brand h1 { font-size: 20px; font-weight: 700; color: #1a1f36; }
        .brand p  { font-size: 13px; color: #888; margin-top: 4px; }

        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 12px; font-weight: 600; color: #555; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .4px; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #bbb; font-size: 14px; }
        .form-control {
            width: 100%; padding: 10px 12px 10px 38px;
            border: 1.5px solid #e0e4ef; border-radius: 8px;
            font-size: 13px; color: #333; outline: none; transition: border-color .2s;
            font-family: inherit;
        }
        .form-control:focus { border-color: #00c897; box-shadow: 0 0 0 3px rgba(0,200,151,.15); }
        .form-control.is-invalid { border-color: #e74c3c; }
        .invalid-feedback { font-size: 11px; color: #e74c3c; margin-top: 4px; }

        .remember-row { display: flex; align-items: center; gap: 8px; margin-bottom: 1.25rem; font-size: 13px; color: #666; }
        .remember-row input[type="checkbox"] { accent-color: #00c897; width: 15px; height: 15px; }

        .btn-login {
            width: 100%; padding: 12px;
            background: #00c897; color: #fff; border: none;
            border-radius: 8px; font-size: 15px; font-weight: 600;
            cursor: pointer; transition: background .2s; font-family: inherit;
            display: inline-flex; align-items: center; justify-content: center; gap: 6px;
        }
        .btn-login:hover { background: #00b386; }
        .btn-login.btn-ghost {
            background: transparent; border: 1.5px solid #dcdfe8; color: #555; font-size: 13px; padding: 10px;
        }
        .btn-login.btn-ghost:hover { background: #f5f6fa; }

        .alert { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 1rem; display: flex; align-items: flex-start; gap: 8px; }
        .alert-danger  { background: #fff0f0; color: #c0392b; border: 1px solid #ffd0d0; border-left: 4px solid #e74c3c; }
        .alert-success { background: #f0fff8; color: #1a7a50; border: 1px solid #b0e8d0; border-left: 4px solid #00c897; }

        .auth-links { text-align: center; font-size: 12.5px; color: #888; margin-top: 1.25rem; }
        .auth-links a { color: #00c897; text-decoration: none; font-weight: 600; }
        .auth-links a:hover { text-decoration: underline; }
        .auth-links .divider { color: #d5d9e4; margin: 0 6px; }

        .hint-box {
            margin-top: 1.5rem; background: #f0faf7;
            border: 1px solid #b0e8d0; border-radius: 8px;
            padding: 12px 14px; font-size: 12px; color: #1a7a50;
        }
        .hint-box strong { display: block; margin-bottom: 4px; }
    </style>
    @yield('extra_css')
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">

        <div class="brand">
            <div class="isp-logo-box" style="width:60px;height:60px;border-radius:14px;font-size:24px;margin:0 auto 12px;background:#00c897;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;flex-shrink:0;">
                <i class="@yield('brand_icon', 'fas fa-wifi')"></i>
            </div>
            <h1>@yield('brand_name', 'ISP Management')</h1>
            <p>@yield('brand_tagline', 'Admin & Staff Portal')</p>
        </div>

        @if(session('status'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('status') }}</span>
            </div>
        @endif

        @if($errors->any())
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ $errors->first() }}</span>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ session('error') }}</span>
            </div>
        @endif

        @yield('auth_content')

        <div class="auth-links">
            @yield('auth_links')
        </div>

    </div>
</div>
</body>
</html>
