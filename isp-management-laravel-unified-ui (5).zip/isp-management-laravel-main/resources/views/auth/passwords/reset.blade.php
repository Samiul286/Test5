{{-- resources/views/auth/passwords/reset.blade.php --}}
{{-- Legacy alias — the NewPasswordController renders auth.reset-password;
     kept for safety and now unified with the shared auth shell. --}}
@extends('auth.reset-password')
