{{-- resources/views/auth/passwords/email.blade.php --}}
{{-- Legacy alias — the PasswordResetLinkController renders auth.forgot-password;
     kept for safety and now unified with the shared auth shell. --}}
@extends('auth.forgot-password')
