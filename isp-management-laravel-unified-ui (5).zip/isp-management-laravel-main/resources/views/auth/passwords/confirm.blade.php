{{-- resources/views/auth/passwords/confirm.blade.php --}}
{{-- Legacy alias — unified with the shared auth shell. --}}
@extends('auth.confirm-password')
