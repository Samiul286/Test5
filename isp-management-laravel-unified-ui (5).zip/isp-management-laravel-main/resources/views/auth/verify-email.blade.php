{{-- resources/views/auth/verify-email.blade.php --}}
{{-- FIX: previously used <x-guest-layout> (nonexistent Breeze component). --}}
@extends('auth.layout')

@section('title', 'Verify Email')
@section('brand_icon', 'fas fa-envelope-open-text')
@section('brand_name', 'ISP Management')
@section('brand_tagline', 'Verify your email address')

@section('auth_content')
<p style="font-size:12.5px; color:#888; margin-bottom:1.25rem;">
    {{ __('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.') }}
</p>

@if (session('status') == 'verification-link-sent')
    <div class="alert alert-success" style="margin-bottom:1.25rem;">
        <i class="fas fa-check-circle"></i>
        <span>{{ __('A new verification link has been sent to the email address you provided during registration.') }}</span>
    </div>
@else
    <div class="hint-box" style="margin-top:0; margin-bottom:1.25rem;">
        <strong><i class="fas fa-info-circle"></i> {{ __('Pending verification') }}</strong>
        {{ __('Your email is still unverified.') }}
    </div>
@endif

<form method="POST" action="{{ route('verification.send') }}">
    @csrf
    <button type="submit" class="btn-login">
        <i class="fas fa-paper-plane"></i> {{ __('Resend Verification Email') }}
    </button>
</form>

<form method="POST" action="{{ route('logout') }}" style="margin-top:10px;">
    @csrf
    <button type="submit" class="btn-login btn-ghost">
        <i class="fas fa-sign-out-alt"></i> {{ __('Log Out') }}
    </button>
</form>
@endsection

@section('auth_links')
    <a href="{{ url()->current() }}">{{ __('Refresh') }}</a>
@endsection
