{{-- resources/views/auth/register.blade.php --}}
@extends('auth.layout')

@section('title', 'Register')
@section('brand_icon', 'fas fa-user-plus')
@section('brand_name', 'ISP Management')
@section('brand_tagline', 'Create a new account')

@section('auth_content')
<form method="POST" action="{{ route('register') }}">
    @csrf

    <div class="form-group">
        <label>{{ __('Name') }}</label>
        <div class="input-wrap">
            <i class="fas fa-user"></i>
            <input type="text" name="name" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                   value="{{ old('name') }}" placeholder="Full name"
                   autocomplete="name" autofocus required>
        </div>
        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
        <label>{{ __('Email') }}</label>
        <div class="input-wrap">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                   value="{{ old('email') }}" placeholder="name@company.com"
                   autocomplete="email" required>
        </div>
        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
        <label>{{ __('Password') }}</label>
        <div class="input-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                   placeholder="••••••••" autocomplete="new-password" required>
        </div>
        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
        <label>{{ __('Confirm Password') }}</label>
        <div class="input-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="password_confirmation" class="form-control"
                   placeholder="••••••••" autocomplete="new-password" required>
        </div>
    </div>

    <button type="submit" class="btn-login">
        <i class="fas fa-user-plus"></i> {{ __('Register') }}
    </button>
</form>
@endsection

@section('auth_links')
    <a href="{{ route('login') }}">{{ __('Already have an account? Login') }}</a>
@endsection
