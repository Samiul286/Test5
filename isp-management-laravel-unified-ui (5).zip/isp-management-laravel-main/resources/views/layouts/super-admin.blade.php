{{-- resources/views/layouts/super-admin.blade.php --}}
@extends('adminlte::page')
@section('title', 'Super Admin — ' . config('adminlte.title'))

{{-- ── Custom user menu (top-right) ──────────────────────────────
     AdminLTE's default user-menu reads Auth::user() (default 'web' guard),
     which is always null for Super Admin (separate 'super_admin' guard).
     This replaces that section entirely with one that explicitly reads
     the correct guard, instead of relying on package internals that
     assume a single guard. --}}
@section('content_top_nav_right')
    <li class="nav-item dropdown user-menu">
        <a class="nav-link dropdown-toggle d-flex align-items-center" data-toggle="dropdown" href="#">
            <span class="user-img-isp mr-1">{{ strtoupper(mb_substr(Auth::guard('super_admin')->user()->name ?? 'SA', 0, 2)) }}</span>
            <span class="d-none d-md-inline">{{ Auth::guard('super_admin')->user()->name ?? 'Super Admin' }}</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="min-width:230px; padding:0; overflow:hidden;">
            <div class="isp-dropdown-header">
                <div class="isp-dropdown-avatar">{{ strtoupper(mb_substr(Auth::guard('super_admin')->user()->name ?? 'SA', 0, 2)) }}</div>
                <div class="min-w-0">
                    <div class="isp-dropdown-name text-truncate">{{ Auth::guard('super_admin')->user()->name ?? 'Super Admin' }}</div>
                    <div class="isp-dropdown-sub text-truncate">{{ Auth::guard('super_admin')->user()->email }}</div>
                </div>
            </div>
            <div class="isp-dropdown-divider"></div>
            <a class="dropdown-item" href="{{ route('super-admin.dashboard') }}">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a class="dropdown-item" href="{{ route('super-admin.notifications.index') }}">
                <i class="fas fa-bullhorn"></i> Send Notification
            </a>
            <div class="isp-dropdown-divider"></div>
            <form action="{{ route('super-admin.logout') }}" method="POST">
                @csrf
                <button type="submit" class="dropdown-item text-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </form>
        </div>
    </li>
@stop

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="m-0">@yield('page_title')</h1>
        <div>@yield('page_actions')</div>
    </div>
@stop

@section('content')
    {{-- Global Toast Notification (unified design system) --}}
    @if(session('success') || session('error') || session('warning'))
    @php
        $type    = session('success') ? 'success' : (session('error') ? 'error' : 'warning');
        $message = session('success') ?? session('error') ?? session('warning');
        $bg      = $type === 'success' ? '#00b386' : ($type === 'error' ? '#e74c3c' : '#f39c12');
        $icon    = $type === 'success' ? 'check-circle' : ($type === 'error' ? 'times-circle' : 'exclamation-triangle');
        $title   = $type === 'success' ? 'Success' : ($type === 'error' ? 'Error' : 'Warning');
    @endphp
    <div class="toast-container-fixed" style="position:fixed; top:20px; right:20px; z-index:9999; min-width:320px; max-width:calc(100vw - 32px);">
        <div class="toast show" role="alert" style="border:none; border-radius:10px; box-shadow:0 10px 30px rgba(26,31,54,.18); overflow:hidden;">
            <div class="toast-header" style="background:{{ $bg }}; color:#fff; border:none; padding:10px 14px;">
                <i class="fas fa-{{ $icon }} mr-2"></i>
                <strong class="mr-auto" style="font-size:13px;">{{ $title }}</strong>
                <button type="button" class="ml-2 close" data-dismiss="toast" style="color:#fff; opacity:1; text-shadow:none; font-size:20px; line-height:1;">&times;</button>
            </div>
            <div class="toast-body" style="background:#fff; font-size:13.5px; color:#444; padding:12px 16px;">
                {{ $message }}
            </div>
        </div>
    </div>
    @endif

    @yield('page_content')
@stop

@section('css')
    <style>
        .badge-active    { background-color: #00c897; }
        .badge-inactive  { background-color: #95a5a6; }
        .badge-suspended { background-color: #f39c12; color: #fff; }
        .badge-expired   { background-color: #e74c3c; }
        .card-header     { font-weight: 600; }
    </style>
    @yield('extra_css')
    @stack('css')
@stop

@section('js')
<script>
setTimeout(function() {
    document.querySelectorAll('.toast').forEach(function(t) {
        $(t).fadeOut(500, function() { $(this).remove(); });
    });
}, 4000);

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.swal-delete').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var form = this.closest('form');
            var msg  = this.getAttribute('data-message') || 'Are you sure?';
            Swal.fire({
                title: 'Are you sure?',
                text: msg,
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#95a5a6',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
            }).then(function(result) {
                if (result.isConfirmed) form.submit();
            });
        });
    });
});
</script>
    @yield('extra_js')
    @stack('js')
@stop
